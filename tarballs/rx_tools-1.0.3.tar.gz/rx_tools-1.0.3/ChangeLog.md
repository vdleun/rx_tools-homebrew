
1.0.3 (2016/11/05)
* Fix sizeof usage for Windows 64 compatibility (closes GH-44)

1.0.2 (2016/10/17)
* Fix link to heatmap script now in rtl-sdr-misc (closes GH-42)

1.0.1 (2016/10/17)
* Update tool help descriptions to use rx instead of rtl names (closes GH-41)

1.0.0 (2016/10/17)
* Initial release
